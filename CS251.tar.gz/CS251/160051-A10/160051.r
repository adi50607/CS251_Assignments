vector<- rexp(50000,0.2)
x<- data.frame(X = seq(1, 50000 , 1), Y = sort(vector))
plot(x)

y <- seq_along(vector)
d1 <- split((vector), ceiling(y/100))

for(i in 1:5) {
  c<- sort(as.numeric(as.character(unlist(d1[i]))))
  d<- (0.2*exp(-0.2*c))
  plot( c,  (d),  xlab="X", ylab="PDF")
  pdata <- rep(0, 100)
  for(i in 1:100){
    val=round(c[i], 0);
    if(val <= 100){
      pdata[val] = pdata[val] + 1/ 100; 
    }
  }
  plot(c, pdata, "l", xlab="X", ylab="PDF")
  cdf <- cumsum(d)
  m <- cdf[100]
  cdf <- cdf/m
  plot(c,cdf, xlab="X", ylab="CDF")
  print(mean(c))
  print(sd(c))
}
a<- rep(0,500)
b<- rep(0,500)
for(j in 1:500) {
  e<-as.numeric(as.character(unlist(d1[j])))
  a[j]<-mean(e)
  b[j]<- sd(e)
}

a<- sort(a)
tab <- table(round(a))
plot(tab, "h", xlab="X", ylab="Frequency")
p<- (0.2*exp(-0.2*a))
plot( a,  p,  xlab="X", ylab="PDF")
pdata2 <- rep(0, 500)
for(i in 1:500){
  val2=round(a[i], 0);
  if(val2 <= 500){
    pdata2[val2] = pdata2[val2] + 1/ 500; 
  }
}
plot(a, pdata2, "l", xlab="X", ylab="PDF")
cdf2 <- cumsum(p)
n <- cdf2[500]
cdf2 <- cdf2/n
plot(a ,cdf2, xlab="X", ylab="CDF")
print(mean(a))
print(sd(a))

print(mean(vector))
print(sd(vector))