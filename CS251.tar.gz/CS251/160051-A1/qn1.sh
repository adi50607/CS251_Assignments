#!/bin/bash

read -p "String: " 
len=${#REPLY}
l=${#REPLY}

while read -r -n 1 -d '' ; do
  array[i++]=$REPLY
done <<< $REPLY

declare -a ones_place=( "" "one" "two" "three" "four" "five" "six" "seven" "eight" "nine" )
declare -a two_digit=( ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen )
declare -a tens_place=( "" "" twenty thirty fourty fifty sixty seventy eighty ninty )
declare -a next_place=( "" "" "" hundred thousand thousand lakh lakh crore crore crore crore )

if [ "$len" -eq 0 ] || [ "$len" -gt 11 ] || [ "$len" -gt 1 -a ${array[0]} -eq 0 ] ; then
   echo "invalid input"
   l=0
else if [ ${array[0]} == 0 ]; then
        echo "zero"
        l=$(($l - 1))
     fi
     
fi

while [ "$l" -gt 0 ]; do
      
      if [ "$l" == 1 ] && [ ${array[0]} -ne 0 ]; then
         echo -n ${ones_place[array[ $len - $l ] ]}
         echo " "
         l=$(($l - 1))
      fi

      if [ "$l" -eq 2 ] && [ ${array[ $len - $l ]} -eq 1 ]; then
         echo -n ${two_digit[array[ $len - $l + 1]  ]}
         echo -n " "
           l=$(($l - 2))
      fi
      if [ "$l" == 2 ] && [ ${array[ $len - $l ]} -ne 1 ]; then
         if [ ${array[ $len - $l ]} -eq 0 ]; then
                 l=$(($l - 1))  
         else
              echo -n ${tens_place[array[ $len - $l ]  ]}
              echo -n " "
              l=$(($l - 1))
         fi
      fi

      if [ "$l" == 3 ] || [ "$l" == 4 ] ; then
         if [ ${array[ $len - $l ]} -ne 0 ]; then
            echo -n ${ones_place[array[ $len - $l ] ]}
            echo -n " "
            echo -n ${next_place[ $l ]}
            echo -n " "
            l=$(($l - 1))
         else 
            l=$(($l - 1))
         
          fi
      fi
      
      if [ "$l" -gt 4 ] && [ "$l" -lt 10 ]; then
         if [ $((l%2)) -eq 1 ]; then
            if [ ${array[ $len - $l ]}  == 1 ]; then
               echo -n ${two_digit[array[ $len - $l + 1] ]}
               echo -n " "
               echo -n ${next_place[ $l ]}
               echo -n " "
               l=$(($l - 2)) 
            
            else 
               if [ ${array[ $len - $l ]} -eq 0 ]; then
                  l=$(($l - 1))  
               
               else 
                  echo -n ${tens_place[array[ $len - $l ]  ]}
                  echo -n " "
                  l=$(($l - 1))
                  if [ ${array[ $len - $l ]} -ne 0 ]; then
                     echo -n ${ones_place[array[ $len - $l ]  ]}
                     echo -n " "
                     echo -n ${next_place[ $l ]}
                     echo -n " "
                     l=$(($l - 1))
                  else 
                     echo -n ${next_place[ $l ]}
                     echo -n " "
                     l=$(($l - 1))
                  fi 
               fi
            fi
         fi
     
          if [ $((l%2)) -eq 0 ]; then
                 if [ ${array[ $len - $l ]} -ne 0 ]; then
                    echo -n ${ones_place[array[ $len - $l ]  ]}
                    echo -n " "
                    echo -n ${next_place[ $l ]}
                    echo -n " "
                    l=$(($l - 1))
                 fi 
                 if [ ${array[ $len - $l ]} -eq 0 ]; then
                    l=$(($l - 1))
                 fi
         fi
      fi
    
      if [ "$l" == 10 ] || [ "$l" == 11 ]; then
         echo -n ${ones_place[array[ $len - $l ]  ]}
         echo -n " "
         echo -n ${next_place[ $((l - 7)) ]}
         echo -n " "
         l=$(($l - 1))
      fi
done
