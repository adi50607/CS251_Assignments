#!/bin/bash

read -p "Enter path: " path
indent=0
sum1=0
sum2=0
pindent(){
            i=0
            while [ $i -lt $indent ];
            do
                  echo -n "   "
                  i=$(($i+1))
            done 
}

func(){
for file in "$1"/*
 do
    
    if [ -d "$file" ]; then
      indent=$(($indent + 1))
                
      echo "   (D)$(basename $file)"
      func $file
    else

     indent=$(($indent + 1))
                   pindent
                   echo -n "(F)$(basename $file)-"
                   indent=$(($indent - 1))
     a=`cat -n $file | tr '.''!''?' "\n" | grep -v "^$" | wc -l`
     echo -n "$a-"
     b=`cat -n $file | grep -o '[0-9]\+' $file | wc -l` 
	c=`cat -n $file | grep -o '[0-9]\+\.[0-9]\+' $file | wc -l` 
     echo $(($b-2*$c))
     sum1=$(($sum1 + $a)) 
     sum2=$(($sum2 + $b)) 
   fi 
 done
indent=$(($indent - 1))
}
func $path
echo "(D)$(basename $path)-$sum1-$sum2"
