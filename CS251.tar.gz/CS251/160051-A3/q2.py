import numpy as np 
from matplotlib import pyplot as plt 
import numpy.matlib

import csv
from collections import defaultdict

result = numpy.loadtxt(open("train.csv", "rb"), delimiter=",", skiprows = 1).astype("float") 
X_train = result[:,[0]]

y_train = result[:,[1]]
x = np.ones((result.shape[0],1)).astype("float")
X_train = np.hstack((x,X_train))

w = np.random.uniform(size=(2,1))
a = X_train.transpose()
b = np.dot(w.transpose(),a)

plt.plot(X_train[:,[1]], y_train, 'ro')
plt.plot(a[1], b.transpose(), 'b')
plt.axis([0, 1200, 0, 13000])
plt.show()

c = np.dot(X_train.transpose(),X_train)
c_inv = numpy.linalg.inv(c)
d = np.dot(X_train.transpose(),y_train)
w_direct = np.dot(c_inv,d)
e = np.dot(w_direct.transpose(),a)

plt.plot(X_train[:,[1]], y_train, 'ro')
plt.plot(a[1], e.transpose(), 'b')
plt.axis([0, 1200, 0, 13000])
plt.show()

for i in range(1,3):
    for j in range(1,result.shape[0]):
        x = result[j][0]
        y = result[j][1]
        x1 = np.array([1,x]).transpose()
        x1 = x1.reshape([2,1])
        f = np.subtract(np.dot(w.transpose(),x1),y)
        w = w-np.multiply(0.00000001*f,x1)
        if j%100==0:
             g = X_train.transpose()
             h = np.dot(w.transpose(),g)
             plt.plot(X_train[:,[1]], y_train, 'ro')
             plt.plot(g[1], h.transpose(), 'b')
             plt.axis([0, 1200, 0, 13000])
             #plt.show()


plt.plot(X_train[:,[1]], y_train, 'ro')
plt.plot(g[1], h.transpose(), 'b')
plt.axis([0, 1200, 0, 13000])
plt.show()



result1 = numpy.loadtxt(open("test.csv", "rb"), delimiter=",", skiprows = 1).astype("float") 
X_test = result1[:,[0]]

y_test = result1[:,[1]]
x = np.ones((result1.shape[0],1)).astype("float")
X_test = np.hstack((x,X_test))

w1 = np.random.uniform(size=(2,1))
a = X_test.transpose()
b = np.dot(w1.transpose(),a)

c = np.dot(X_test.transpose(),X_test)
c_inv = numpy.linalg.inv(c)
d = np.dot(X_test.transpose(),y_test)
w_direct1 = np.dot(c_inv,d)
e = np.dot(w_direct1.transpose(),a)

for i in range(1,3):
    for j in range(1,result1.shape[0]):
        x = result1[j][0]
        y = result1[j][1]
        x1 = np.array([1,x]).transpose()
        x1 = x1.reshape([2,1])
        f = np.subtract(np.dot(w1.transpose(),x1),y)
        w1 = w1-np.multiply(0.00000001*f,x1)
        
y_pred1 = np.dot(X_test,w1)
y1=np.subtract(y_pred1,y_test)
y2=np.square(y1)
y3 = np.mean(y2)
root_mean_sqr1 =np.sqrt(y3)
print root_mean_sqr1
y_pred2 = np.dot(X_test,w_direct1)
y4=np.subtract(y_pred2,y_test)
y5=np.square(y4)
y6 = np.mean(y5)
root_mean_sqr2 = np.sqrt(y6)
print root_mean_sqr2




