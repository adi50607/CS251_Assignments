#!/usr/bin/python
import sys
import decimal

def val(x):
   if ord(x) == 46:
      return 0;
   elif ord(x) <= 57:
      return (ord(x)-48);
   else:
      return (ord(x)-55);

frac = sys.argv[1]
if len(sys.argv[2])==2:
   base=(ord(sys.argv[2][0])-48)*10 + (ord(sys.argv[2][1])-48)
else:
   base=ord(sys.argv[2][0]) - 48

i=j=k=value=value1=value2=tmp=0
a=1
while k<len(frac):
   if val(frac[k]) >= base:
      print "Invalid Input"
      tmp=1
      k=k+1
      break;
   else:
      k=k+1   
if tmp==0:
   if ord(frac[0])==45:
        if len(frac)==len(frac.split('.')[0]):
		while i < len(frac)-1:
		    value = value + (val(frac[len(frac)-1-i]) * a)
		    a=a*base
		    i=i+1
		print value*(-1) 
	else:
		while i < len(frac.split('.')[0])-1:
		    value1 = value1 + (val(frac[len(frac.split('.')[0])-1-i]) * float(a))
		    a=a*base
		    i=i+1
		a=base
		while j < len(frac.split('.')[1]):
		    value2 = value2 + val(frac.split('.')[1][j]) / float(a)
		    a=a*base
		    j=j+1
		print (float(value1)+float(value2))*(-1)
   else:
	if len(frac)==len(frac.split('.')[0]):
		while i < len(frac):
		    value = value + (val(frac[len(frac)-1-i]) * a)
		    a=a*base
		    i=i+1
		print value 
	else:
		while i < len(frac.split('.')[0]):
		    value1 = value1 + (val(frac[len(frac.split('.')[0])-1-i]) * float(a))
		    a=a*base
		    i=i+1
		a=base
		while j < len(frac.split('.')[1]):
		    value2 = value2 + val(frac.split('.')[1][j]) / float(a)
		    a=a*base
		    j=j+1
                value = decimal.Decimal(value1+value2)
                print value
	  

