import os
import sys

x = 5

# Hello World
# def func1():
# 	print "Hello World!"

# func1()


# def func2():
# 	x = 4
# 	print x

# print x
# func2()
# print x

# Using global variables in function
# def func3():
# 	global x
# 	print x
# 	x = x + 5

# print x
# func3()
# print x

# Arguments and return from function
# def func4(a, b=4):
# 	c = a + 5
# 	d = b - 6

# 	return c, d

# a = 10
# b = 20

# x, y = func4(a)
# print x, y

# x, y = func4(a, b)
# print x, y

# List is passed by reference
# def func5(a):
# 	a[0] = 15
# 	return a

# x = [2,3,4]
# print x
# y = func5(x)
# print y
# print x