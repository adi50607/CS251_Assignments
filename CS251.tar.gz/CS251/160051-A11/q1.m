format long g

result=dlmread('train.csv','',1,0);
X_train=result(:,1);
Y_train=result(:,2);
o=ones(size(Y_train), 1);
X_train=[o,X_train];


w=rand(2,1);


a=(X_train)';
b=(w)'*a;
plot(X_train(:,2),Y_train,'ro',a(2,:),b','-')
pause(.5);


w_direct=inv((X_train)'*X_train)*(X_train)'*Y_train;
e=(w_direct)'*a;
plot(X_train(:,2),Y_train,'ro',a(2,:),e','-')
pause(.5);


for i=1:3
   for j=1:size(Y_train)
       x=result(j,1);
       y=result(j,2);
       x1=[1,x];
       w=w-0.00000001*(w'*x1'-y)*x1';
       if (rem(j,100)==0)
           h=w'*a;
           plot(X_train(:,2),Y_train,'ro',a(2,:),h','-')
           pause(.5);
       endif
   endfor
endfor


g=w'*a;
plot(X_train(:,2),Y_train,'ro',a(2,:),g','-')
pause(.5);




result1=dlmread('test.csv','',1,0);
X_test=result1(:,1);
Y_test=result1(:,2);
o1=ones(size(Y_test), 1);
X_test=[o1,X_test];


w1=rand(2,1);


a1=(X_test)';
b1=(w1)'*a;


w_direct1=inv((X_test)'*X_test)*(X_test)'*Y_test;
e1=(w_direct1)'*a1;


for p=1:3
   for q=1:size(Y_test)
       x=result1(q,1);
       y=result1(q,2);
       x2=[1,x];
       w1=w1-0.00000001*(w1'*x2'-y)*x2';
   endfor
endfor


y_pred1=X_test*w1;
y_pred2=X_test*w_direct1;
y1=sqrt(meansq(y_pred1-Y_test))
y2=sqrt(meansq(y_pred2-Y_test))
