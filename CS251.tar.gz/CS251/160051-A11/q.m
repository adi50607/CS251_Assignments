format long g

result1=dlmread('test.csv','',1,0);
X_test=result1(:,1);
Y_test=result1(:,2);
o1=ones(1000, 1);
X_test=[o1,X_test];


w1=rand(2,1);


a1=(X_test)';
b1=(w)'*a;


w_direct1=inv((X_test)'*X_test)*(X_test)'*Y_test;
e1=(w_direct1)'*a1;


for p=1:3
   for q=1:1000
       x=result(q,1);
       y=result(q,2);
       x2=[1,x];
       w1=w1-0.00000001*(w1'*x2'-y)*x2';
   endfor
endfor


y_pred1=X_test*w1;
y_pred2=X_test*w_direct1;
y1=sqrt(meansq(y_pred1-Y_test))
y2=sqrt(meansq(y_pred2-Y_test))
