#include <common.h>
int do_gpu(void)
{
   return do_math();
}
