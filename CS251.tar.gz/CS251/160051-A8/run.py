import numpy as np 
import subprocess
import re
import math

crs = open("params.txt", "r")
for columns in ( raw.strip().split() for raw in crs ):  
        arr1=columns
	len1=len(columns)
        

crs = open("threads.txt", "r")
for columns in ( raw.strip().split() for raw in crs ):  
        arr2=columns
        len2=len(columns)
   
    
f = open('out.txt', 'w')
g = open('out2.txt', 'w')
for i in range(0,len1):
        arr11=[0,0,0,0,0]
	arr22=[0,0,0,0,0]
        a=int(arr1[i])
        x=math.log10(a)
	for k in range(0,100):
		for j in range(0,len2):
		        b=int(arr2[j])
		        cmd= "./app %d %d"%(a,b)
			string = subprocess.check_output(cmd, stdin=None, stderr=subprocess.STDOUT,shell=True)
			c = re.split(' ',string)
			d=int(c[3])
                        arr11[j]=arr11[j]+d
			arr22[j]=arr22[j]+d*d
		        f.write("%d %d %d\n"%(x,b,d))
		#f.write("\n")
	x1=(arr22[0]/100)-(arr11[0])*(arr11[0]/10000)
	x2=(arr22[1]/100)-(arr11[1])*(arr11[1]/10000)
	x3=(arr22[2]/100)-(arr11[2])*(arr11[2]/10000)
	x4=(arr22[3]/100)-(arr11[3])*(arr11[3]/10000)
	x5=(arr22[4]/100)-(arr11[4])*(arr11[4]/10000)
	g.write("%d %d %d %d %d %d %d %d %d %d %d \n"%(x,arr11[0]/100,arr11[1]/100,arr11[2]/100,arr11[3]/100,arr11[4]/100,x1,x2,x3,x4,x5))
