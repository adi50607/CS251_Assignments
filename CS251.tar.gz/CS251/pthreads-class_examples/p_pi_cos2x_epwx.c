#include <stdio.h>
#include <stdlib.h>
#include<pthread.h>

#ifndef INFINITE_SUM_FUNCTIONS
   #define INFINITE_SUM_FUNCTIONS

#define PI_ITERS 1000000
#define COS_ITERS 1000
#define EPOW_ITERS 1000

#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <value of x>\n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

extern double epow (double x);
extern double cosine (double x);
extern double pi (void);

#endif


double pi(void)
{
    double sum = 1.0;
    int ctr;
    for(ctr=1; ctr < PI_ITERS; ++ctr){
          double add = (1.0)/(2*ctr + 1.0);
          if(ctr % 2 == 0) 
             sum += add;
          else
             sum -= add;
    }
   return (sum * 4);
}

double cosine(double x)
{
     double sum = 1;
     int ctr;
     double factorial = 1.0;
     double xpow = 1.0;
     for(ctr=1; ctr < COS_ITERS; ctr++){
          double add = 0.0;
          factorial *= ctr * (ctr + 1);
          xpow *= x * x;
          add = xpow / factorial;
          if(ctr % 2 == 0) 
             sum += add;
          else
             sum -= add;
          
     }
   return sum;
}

double epow(double x)
{
     double sum = 1;
     int ctr;
     double factorial = 1.0;
     double xpow = 1.0;
     for(ctr=1; ctr < EPOW_ITERS; ctr++){
          double add = 0.0;
          factorial *= ctr;
          xpow *= x;
          add = xpow / factorial;
          sum += add;
          
     }
   return sum;
}



double pi_ret, cos_ret, eval_ret;

void *calc_pi(void *arg)
{
    pi_ret = pi();
    pthread_exit(&pi_ret);
}

void *calc_cos(void *arg)
{
    cos_ret = cosine(*((double *)arg));
    pthread_exit(&cos_ret);
}

void *calc_epow(void *arg)
{
    eval_ret = epow(*((double *)arg));
    pthread_exit(&eval_ret);
}

int main(int argc, char **argv)
{
     
    double x, pival, cosval, eval; 
    void *retval;
    pthread_t threads[2];

    if(argc != 2)
          USAGE_EXIT("invalid args\n");
    x = atof(argv[1]);
    
    if(x > 1.0 || x < 0.0)
          USAGE_EXIT("invalid args\n");
    
    
    if(pthread_create(&threads[0], NULL, calc_pi, NULL) != 0){
              perror("pthread_create");
              exit(-1);
    }
    if(pthread_create(&threads[1], NULL, calc_cos, &x) != 0){
              perror("pthread_create");
              exit(-1);
    }
    if(pthread_create(&threads[2], NULL, calc_epow, &x) != 0){
              perror("pthread_create");
              exit(-1);
    }
    
    if(pthread_join(threads[0], &retval) != 0){
              perror("pthread_join 1");
              exit(-1);
    } 
    pival = *((double *)retval);
    printf("%.5f\n", pival); 
    
    if(pthread_join(threads[1], &retval) != 0){
              perror("pthread_join 2");
              exit(-1);
    } 
    cosval = *((double *)retval);
    printf("%.5f\n", cosval); 
   
    if(pthread_join(threads[2], &retval) != 0){
              perror("pthread_join 3");
              exit(-1);
    }
    eval = *((double *)retval);
    printf("%.5f\n", eval); 

    printf("Function = %f\n", pival * cosval * cosval / eval);     
}
