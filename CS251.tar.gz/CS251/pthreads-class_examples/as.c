#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<pthread.h>
#include <unistd.h>
#include <ctype.h>


#define THREADS 1
#define BLOCK_SIZE 64

pthread_mutex_t lock;
static char *dataptr;
static unsigned long *optr;

char *p;
int num_words=0;
int max_words=0;
void getwords(char *word[]){
        int num_words=0;

	while(1){
		while(isspace(*p))
			p++;

		//if(*p == '\0')
		//	return;

		word[num_words++] = p;

		while(!isspace(*p) && *p != '\0')
			p++;
		*p++ = '\0';
		
		if(num_words==max_words)
			return;

	}
}



int main(int argc, char **argv)
{
     int fd1, fd2, ctr;
     unsigned long size1, size2, bytes_read1 = 0, bytes_read2=0;
     char *buff1, *buff2, *cbuff1, *cbuff2;
     char *p1,*p2;
     int ac[10000];
     int a=atoi(argv[3]);
     int no[a],type[a],ac1[a],ac2[a];
     double amount[10000],amount0[a];
     int num_threads=atoi(argv[4]);
     pthread_t threads[num_threads];

     if(argc != 5){
            printf("Usage: %s <fileneme>\n", argv[0]);
            exit(-1);         
      }  
     fd1 = open(argv[1], O_RDONLY);
     if(fd1 < 0){
           printf("Can not open file\n");
           exit(-1);
     } 
    
     fd2 = open(argv[2], O_RDONLY);
     if(fd2 < 0){
           printf("Can not open file\n");
           exit(-1);
     } 
    
    size1 = lseek(fd1, 0, SEEK_END);
    if(size1 <= 0){
           perror("lseek");
           exit(-1);
    }
    
    size2 = lseek(fd2, 0, SEEK_END);
    if(size2 <= 0){
           perror("lseek");
           exit(-1);
    }
    
    if(lseek(fd1, 0, SEEK_SET) != 0){
           perror("lseek");
           exit(-1);
    }
   
     if(lseek(fd2, 0, SEEK_SET) != 0){
           perror("lseek");
           exit(-1);
    }
   
    buff1 = malloc(size1);
    if(!buff1){
           perror("mem");
           exit(-1);
    } 

    buff2 = malloc(size2);
    if(!buff2){
           perror("mem");
           exit(-1);
    }   
   /*Read the complete file into buff
     XXX Better implemented using mmap */
   
    do{
         unsigned long bytes1;
         cbuff1 = buff1 + bytes_read1;
         bytes1 = read(fd1, cbuff1, size1 - bytes_read1);
         if(bytes1 < 0){
             perror("read");
             exit(-1);
         }
        bytes_read1 += bytes1;
     }while(size1 != bytes_read1);

      do{
         unsigned long bytes2;
         cbuff2 = buff2 + bytes_read2;
         bytes2 = read(fd2, cbuff2, size2 - bytes_read2);
         if(bytes2 < 0){
             perror("read");
             exit(-1);
         }
        bytes_read2 += bytes2;
     }while(size2 != bytes_read2);
 
	p=buff1;
	char *word1[2];
	max_words=2;
	for(int i=0;i<10000;i++){
		getwords(word1);
		ac[i]=atoi(word1[0]);
		amount[i]=atof(word1[1]);
                //printf("%d  %f\n",ac[i],amount[i]);
	}
        p=buff2;
        char *word2[5];
        max_words=5;
	for(int j=0;j<a;j++){
	       getwords(word2);
               no[j]=atof(word2[0]);
               type[j]=atoi(word2[1]);
               amount0[j]=atof(word2[2]);
               ac1[j]=atoi(word2[3]);
               ac2[j]=atoi(word2[4]);
               if(type[j]==1){
                    amount[ac1[j]-1001] += amount0[j]*99/100;
               }
               if(type[j]==2){
                    amount[ac1[j]-1001] -= amount0[j]*101/100;
               }
               if(type[j]==3){
                    amount[ac1[j]-1001] += (7.1/100)*amount[ac1[j]-1001];
               }
               if(type[j]==4){
                    amount[ac1[j]-1001] -= amount0[j]*101/100;
                    amount[ac2[j]-1001] += amount0[j]*99/100;
               }

               //printf("%d  %d  %f  %d  %d\n",no[j],type[j],amount0[j],ac1[j],ac2[j]);
	}
        for(int i=0;i<10000;i++){
                printf("%d  %f\n",ac[i],amount[i]);
	}
       



/*void getwords(char *word[]){
        int num_words=0;

	while(1){
		while(isspace(*p))
			p++;

		//if(*p == '\0')
		//	return;

		word[num_words++] = p;

		while(!isspace(*p) && *p != '\0')
			p++;
		*p++ = '\0';
		
		if(num_words==max_words)
			return;

	}
}


void cal(int *ptr, int *endptr){
        p=buff2;
        char *word2[5];
        max_words=5;
	for(int j=0;j<endptr-ptr;j++){
	       getwords(word2);
               no[j]=atof(word2[0]);
               type[j]=atoi(word2[1]);
               amount0[j]=atof(word2[2]);
               ac1[j]=atoi(word2[3]);
               ac2[j]=atoi(word2[4]);
               if(type[j]==1){
                    amount[ac1[j]-1001] += amount0[j]*99/100;
               }
               if(type[j]==2){
                    amount[ac1[j]-1001] -= amount0[j]*101/100;
               }
               if(type[j]==3){
                    amount[ac1[j]-1001] += (7.1/100)*amount[ac1[j]-1001];
               }
               if(type[j]==4){
                    amount[ac1[j]-1001] -= amount0[j]*101/100;
                    amount[ac2[j]-1001] += amount0[j]*99/100;
               }       

}


void *function(void *arg)
//Argument is the end pointer//
{
   char *cptr;
   unsigned long *chash;
   char *endptr = (char *)arg;

   while(1){
        pthread_mutex_lock(&lock);
        if(dataptr >= endptr){
              pthread_mutex_unlock(&lock);
              break;
        }
        cptr = dataptr;
        dataptr += BLOCK_SIZE;
        
        chash = optr;
        optr++;
        pthread_mutex_unlock(&lock);
   
        //Perform the real calculation//
        cal;
        
         


  }
  pthread_exit(NULL); 
}


pthread_mutex_init(&lock, NULL);
  
     cbuff2 = buff2 + size2;

for(ctr=0; ctr < num_threads; ++ctr){
        if(pthread_create(&threads[ctr], NULL, function, cbuff2) != 0){
              perror("pthread_create");
              exit(-1);
        }
 
     }

for(ctr=0; ctr < num_threads; ++ctr)
            pthread_join(threads[ctr], NULL);*/



}
