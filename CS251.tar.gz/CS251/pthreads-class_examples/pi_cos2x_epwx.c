#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<math.h>

#ifndef INFINITE_SUM_FUNCTIONS
   #define INFINITE_SUM_FUNCTIONS

#define PI_ITERS 1000000
#define COS_ITERS 1000
#define EPOW_ITERS 1000

#define USAGE_EXIT(s) do{ \
                             printf("Usage: %s <value of x>\n %s\n", argv[0], s); \
                            exit(-1);\
                    }while(0);

extern double epow (double x);
extern double cosine (double x);
extern double pi (void);

#endif


double pi(void)
{
    double sum = 1.0;
    int ctr;
    for(ctr=1; ctr < PI_ITERS; ++ctr){
          double add = (1.0)/(2*ctr + 1.0);
          if(ctr % 2 == 0) 
             sum += add;
          else
             sum -= add;
    }
   return (sum * 4);
}

double cosine(double x)
{
     double sum = 1;
     int ctr;
     double factorial = 1.0;
     double xpow = 1.0;
     for(ctr=1; ctr < COS_ITERS; ctr++){
          double add = 0.0;
          factorial *= ctr * (ctr + 1);
          xpow *= x * x;
          add = xpow / factorial;
          if(ctr % 2 == 0) 
             sum += add;
          else
             sum -= add;
          
     }
   return sum;
}

double epow(double x)
{
     double sum = 1;
     int ctr;
     double factorial = 1.0;
     double xpow = 1.0;
     for(ctr=1; ctr < EPOW_ITERS; ctr++){
          double add = 0.0;
          factorial *= ctr;
          xpow *= x;
          add = xpow / factorial;
          sum += add;
          
     }
   return sum;
}


/*calculate pi * cos^2x / e^x 
  X is input */

int main(int argc, char **argv)
{
     
    double x, pival, cosval, eval; 
    if(argc != 2)
          USAGE_EXIT("invalid args\n");
    x = atof(argv[1]);
    
    if(x > 1.0 || x < 0.0)
          USAGE_EXIT("invalid args\n");

    pival = pi();
    cosval = cos(x);
    eval = epow(x);
    
    printf("Function = %f\n", pival * cosval * cosval / eval);     
}
